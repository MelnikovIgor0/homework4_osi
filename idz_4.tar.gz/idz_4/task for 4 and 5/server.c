#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
    if (argc != 2)
    {
        fprintf(stderr, "Usage:  %s <Server Port>\n", argv[0]);
        exit(1);
    }

    int echoServPort = atoi(argv[1]);

    int socket_desc;
    struct sockaddr_in server_addr, client_addr;
    char server_message[2000], client_message[2000];
    int client_struct_length = sizeof(client_addr);
    unsigned int childProcCount = 0;
    
    // Clean buffers:
    memset(server_message, '\0', sizeof(server_message));
    memset(client_message, '\0', sizeof(client_message));
    
    // Create UDP socket:
    socket_desc = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    
    if(socket_desc < 0){
        printf("Error while creating socket\n");
        return -1;
    }
    printf("Socket created successfully\n");
    
    // Set port and IP:
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(echoServPort);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    // Bind to the set port and IP:
    if(bind(socket_desc, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0){
        printf("Couldn't bind to the port\n");
        return -1;
    }
    printf("Done with binding\n");
    
    printf("Listening for incoming messages...\n\n");

    if (recvfrom(socket_desc, client_message, sizeof(client_message), 0,
        (struct sockaddr*)&client_addr, &client_struct_length) < 0){
          printf("Couldn't receive\n");
          return -1;
    }
    
    for (int i = 0; i < 3; ++i) {
        if (!fork()) {
            int clientNum = 1;
            char echoBuffer[] = "lolkeklolkek";
            while (1) {
                snprintf(echoBuffer, sizeof(echoBuffer), "%d", clientNum);
                printf("Created client %d in process %d\n", clientNum, getpid());
                if (sendto(socket_desc, echoBuffer, strlen(echoBuffer), 0,
                    (struct sockaddr*)&client_addr, client_struct_length) < 0) {
                     printf("Can't send!!!\n");
                     return -1;
                }

                if (recvfrom(socket_desc, client_message, sizeof(client_message), 0,
                    (struct sockaddr*)&client_addr, &client_struct_length) < 0){
                      printf("Couldn't receive\n");
                      return -1;
                }
                printf("Client %d in process %d processed\n", clientNum, getpid());
                ++clientNum;

                sleep(1);
            }

            exit(0);
        }
        childProcCount++;
        while (childProcCount)
        {
            if (waitpid((pid_t) -1, NULL, WNOHANG) == 0)
                break;
            else
                childProcCount--;
        }
    }

    close(socket_desc);
    
    return 0;
}

